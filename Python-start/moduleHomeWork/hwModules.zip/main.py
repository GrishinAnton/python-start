from create_directory.dir import create_directories, remove_directories
from shuffle.shuffleList import shuffle


# create_directories()
# remove_directories()
# some_list = [1,2,3,4,5]
# print(shuffle(some_list))

